import numpy as np


def estimate_fundamental_matrix(points_a, points_b):
    """
    Calculates the fundamental matrix. Try to implement this function as
    efficiently as possible. It will be called repeatedly in part 3.
    Args:
    -   points_a: A numpy array of shape (N, 2) representing the 2D points in
                  image A
    -   points_b: A numpy array of shape (N, 2) representing the 2D points in
                  image B
    -   normalize: Boolean, set to "True" if you normalize the coordinates
                   before calculating F
    Returns:
    -   F: A numpy array of shape (3, 3) representing the fundamental matrix
    """
    F = np.zeros(3, 3)

    ##############################
    # TODO: Student code goes here
    raise NotImplementedError
    ##############################

    return F
